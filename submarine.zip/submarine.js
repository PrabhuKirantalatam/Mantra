const pubnub = new PubNub({
    publishKey: 'pub-c-264a4873-4055-4f4b-a6b5-4d379535f69b',
    subscribeKey: 'sub-c-10d20aec-aa30-4227-b2d2-682231a0df64'
});

const submarineNameInput = document.getElementById('submarineName');

const statusSpan = document.getElementById('status');

pubnub.addListener({
    message: function (message) {
        // Handle messages received from the control room
        const { action } = message.message;

        if (action === 'hide') {
            // Handle hide command from control room
            hideSubmarine();
        }
    }
});

function registerSubmarine() {
    const submarineName = submarineNameInput.value.trim();
	alert("submarineNameInput "+submarineName);
    // Validate submarine name
    if (/^[a-zA-Z0-9]+$/.test(submarineName)) {
        // Register the submarine with the control room
        pubnub.setState({
            channels: ['submarines_channel'],
            state: { submarineName }
        });
//chatMessageChannel = 'chat-signals-example',
//isTypingChannel = 'is-typing';
//pubnub.subscribe({ channels: [chatMessageChannel, isTypingChannel] }); // Subscribe to a channel.

        // Display registration success
        //console.log("Submarine ${'submarineName'} registered successfully.");
    } else {
        // Show an error for invalid submarine name
       // console.error('Invalid submarine name. Please use alphanumeric characters only.');
    }
}

function hideSubmarine() {
    // Update status when the submarine receives a hide command
    statusSpan.textContent = 'Hidden';
    
    // Remove the submarine from the control room's list (optional)
    pubnub.unsubscribe({
        channels: ['submarines_channel']
    });
}
