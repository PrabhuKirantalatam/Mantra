const pubnub = new PubNub({
  publishKey: 'pub-c-264a4873-4055-4f4b-a6b5-4d379535f69b',
  subscribeKey: 'sub-c-10d20aec-aa30-4227-b2d2-682231a0df64'
});

const submarineList = document.getElementById('submarineList');
//alert("submarineList "+submarineList);

pubnub.addListener({
    message: function (message) {
        // Handle messages received from submarines
        const { action, submarineName } = message.message;

        if (action === 'hide') {
            // Handle hide command from submarine
            disableSubmarine(submarineName);
        }
    },
    presence: function (presence) {
        // Handling join and leave events
        updateSubmarineList(presence);
    }
});

pubnub.subscribe({
    channels: ['submarines_channel'],
    withPresence: true
});

//chatMessageChannel = 'chat-signals-example',
//isTypingChannel = 'is-typing';
//pubnub.subscribe({ channels: [chatMessageChannel, isTypingChannel] }); // Subscribe to a channel.

function updateSubmarineList(presence) {
    const submarineName = presence.uuid;

    if (presence.action === 'join') {
        // Add submarine to the list
        addSubmarine(submarineName);
    } else if (presence.action === 'leave') {
        // Remove submarine from the list
        removeSubmarine(submarineName);
    }
}

function addSubmarine(submarineName) {
    // Check if the name is already taken
    if (!document.getElementById(submarineName)) {
        const listItem = document.createElement('li');
        listItem.id = submarineName;
        listItem.innerHTML = `
            ${submarineName}
            <button onclick="sendHideCommand('${submarineName}')">Hide</button>
        `;
        submarineList.appendChild(listItem);
    } else {
        // Send an error to re-register with a proper name
        //console.error('Submarine with name '${submarineName}' already exists. Please choose a different name.');
    }
}

function removeSubmarine(submarineName) {
    // Remove submarine from the list
    const listItem = document.getElementById(submarineName);
    if (listItem) {
        listItem.remove();
    }
}

function disableSubmarine(submarineName) {
    // Disable submarine button after receiving hide command
    const hideButton = document.getElementById(submarineName);
    if (hideButton) {
        hideButton.querySelector('button').disabled = true;
    }
}

function sendHideCommand(submarineName) {
    // Send hide command to the selected submarine
    pubnub.publish({
        channel: 'submarines_channel',
        message: { action: 'hide', submarineName }
    });
}
